#!/bin/bash

# Sets up the files to be included in the release

mkdir .artifacts
zip -r ./.artifacts/Overworld.zip *
